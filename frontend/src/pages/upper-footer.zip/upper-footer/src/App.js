// import logo from './logo.svg';
import './App.css';
import Upperfooter from './upperfooter/Upperfooter';

function App() {
  return (
    <div className="App">
      <Upperfooter />
    </div>
  );
}

export default App;
